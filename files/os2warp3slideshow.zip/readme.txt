This is a Warp demo, made for IBM by ASDI, which fits quite nicely on one disk.
It's a DOS app but it runs in a full screen DOS session under OS/2 as well (but
I couldn't get any sound out of the PC-speaker). It starts with the familiar 
white Warp logo on a black background, IBM's copyright blabla , then a blue 
background appears with several icons to click on: BonusPack,
Internet, How to order, etc. It runs stand-alone if nobody is there
to operate the mouse or the keyboard. The only gripe I have with this
demo is that you'll have to press a key to get past that IBM copyright
screen. Since I intend this demo to run on store PC's I think that's
a disadvantage. Every morning the power is plugged back in so the
demo waits until a customer is brave enough to press a key.
Don't count on the sales people to press that key...

This is not the same demo as ibm/ews/warpdm.zip on Hobbes! I like this one 
better (more interactive) but warpdm.zip starts spectacularly with raytraced
anims of old and new cars, planes and analogies with DOS and Windows (I like that!).
My biggest gripe with warpdm.zip is that that superb animation is played only
the first time the demo is started...

Jacco de Leeuw (leeuw@fwi.uva.nl)
